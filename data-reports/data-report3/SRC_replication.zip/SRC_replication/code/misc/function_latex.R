# MISCELLANEOUS AUXILIARY FUNCTIONS

compile_latex = function(file=NULL, file_key=NULL, folder) {
  # This script compiles the tex document specified in path_to.
  
  # Save current wd
  main_wd = getwd()
  
  # File path to tex document
  if (is.null(file)) {
    file = path_to(file_key)
  }
  
  # Compile from folder
  setwd(path_to(folder))
  texi2pdf(file = file,
           clean = TRUE, quiet = TRUE,
           texi2dvi = getOption("texi2dvi"),
           texinputs = NULL, index = TRUE)
  
  # Restore wd
  setwd(main_wd)
}