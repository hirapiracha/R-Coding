# MISCELLANEOUS AUXILIARY FUNCTIONS
library("rjson")

path_to = function(file_name, add_string = "", render_rmd = F) {
  # This script provides a function that returns the absolute file paths of different
  # files.  First, all files are imported from in a separate dictionary which contains
  # the relative file path of each file (relative to the root of the analysis folder).
  # Then, the function adds the root plus additional string at the end and returns
  # the resulting file path.
  # If Rmd is rendered (which changes the directory and breaks the paths specified in file_paths),
  # this is taken into account
  
  # Recover path of root
  root = paste(getwd(), "/", sep = "")
  
  # Correct if Rmd is rendered
  if (render_rmd) {
    root = sub("out/rmd", "", root)
  }
  
  # Import file paths dictionary
  files = fromJSON(file=paste(root, "code/specs/file_paths.json", sep= ""))
  
  # Determine final file path
  path = paste(root, files[file_name], add_string, sep = "")
  
  return(path)
}