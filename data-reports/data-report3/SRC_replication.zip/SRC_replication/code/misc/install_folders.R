# This script creates the necessary file structure.

folders = c(
  "out",
  "data_out",
  "tables",
  "figures",
  "table_viewer"
)
  
for (f in folders) {
  ifelse(!dir.exists(path_to(f)), dir.create(path_to(f)), FALSE)
}