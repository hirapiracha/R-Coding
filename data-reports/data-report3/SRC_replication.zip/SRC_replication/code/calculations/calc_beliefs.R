# Purpose: Derive summary statistics for beliefs in dampening that are reported
# in the main text.


######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
s = readRDS(path_to("wide"))


######################
#### IN-TEXT NUMBERS #
######################
# I calculate averages across vignettes and respondents.
# The paper cites averages across respondents.

# Range of dampening beliefs across vignettes
stats = s %>% group_by(vig) %>%
  summarise(mean(1*(effect == 3 | effect == 4)))
stats
min(stats[,2])
max(stats[,2])

# Average shares: dampening
mean(stats[,2, drop=T]) # across vignettes
mean(s$effect == 3 | s$effect == 4) # across respondents

# Average share: full dampening
stats2 = s %>% group_by(vig) %>%
  summarise(mean(1*(effect == 4)))
mean(stats2[,2, drop=T])/mean(stats[,2, drop=T])
mean(s$effect == 4)/mean(s$effect == 3 | s$effect == 4) # Full dampening relative to any dampening

# Average dampening factor
stats3 = s %>% group_by(vig) %>%
  summarise(1 - mean(quant_effect))
min(stats3[,2])
max(stats3[,2])
mean(stats3[,2, drop=T])
mean(1-s$quant_effect)

# Separate results for reduction and reallocation scenarios.
s$type = ifelse(grepl("^sub", s$vig), "reallocation", "reduction")
s %>% group_by(type) %>% summarise(
  full = mean(effect == 4),
  partial = mean(effect == 3),
  any = full + partial,
  rel_share_full = full/(full + partial),
  naive = mean(effect == 2)
)

