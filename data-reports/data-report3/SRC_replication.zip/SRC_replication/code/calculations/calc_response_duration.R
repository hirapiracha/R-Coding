# Purpose: Derive response duration.

# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
w = readRDS(path_to("wide"))

# Calculate
quantile(w$Duration__in_seconds_/60, seq(0, 1, 0.1))
