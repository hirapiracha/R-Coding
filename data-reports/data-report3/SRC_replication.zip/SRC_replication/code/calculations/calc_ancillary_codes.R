# Purpose: Derive frequency of ancillary codes.

######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
s = readRDS(path_to("wide"))


######################
#### DERIVE STATS ####
######################
## DAMPENING BELIEFS
# Freq for junk
mean(grepl("junk", s$code_effect[!is.na(s$code_effect)]))

# Freq for misunderstanding
mean(grepl("misunderstanding", s$code_effect[!is.na(s$code_effect)]))

# Freq for dampening mech versus tiny
mean(grepl("tiny", s$code_effect[!is.na(s$code_effect)]) & !grepl("dampening", s$code_effect[!is.na(s$code_effect)]))/mean(s$code_effect_simple == "dampening", na.rm=T)
mean(grepl("dampening", s$code_effect[!is.na(s$code_effect)]))/mean(s$code_effect_simple == "dampening", na.rm=T)

## SOCIAL CONCERNS
# Freq for junk
mean(grepl("junk", s$code_conseq[!is.na(s$code_conseq)]))

# Freq for misunderstanding
mean(grepl("misunderstanding", s$code_conseq[!is.na(s$code_conseq)]))

# Freq for conseqstill (provide conseq argument even though ineffective valuation > 0)
mean(grepl("conseqstill", s$code_conseq[!is.na(s$code_conseq)]))

# Freq for different motivation for deont
mean(grepl("deont:principle", s$code_conseq[!is.na(s$code_conseq)]))
mean(grepl("deont:feelgood", s$code_conseq[!is.na(s$code_conseq)]))
mean(grepl("deont:ownpart", s$code_conseq[!is.na(s$code_conseq)]))
