# Purpose: Derive attrition.

######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
w = readRDS(path_to("attrition"))


#### STATS ON ATTRITION ####
# Screen-out counts from Qualtrics
# consent: 1
# mobile: 37
# attention: 41
# do not provide sufficient data in intro: 15 (data from clean_survey)

# Conditional on reaching the main part.
table(w$completed_belief)
table(w$completed_belief) %>% prop.table %>% round(2)

table(w$completed_conseq)
table(w$completed_conseq) %>% prop.table %>% round(2)

table(w$completed_survey)
table(w$completed_survey) %>% prop.table %>% round(2)

table(w$final_sample)
table(w$final_sample) %>% prop.table %>% round(2)
