# Purpose. Derive median valuation of effective/ineffective externality reduction.

# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
w = readRDS(path_to("wide"))

# Median of valuation in different scenarios
w %>% group_by(conseq) %>% summarise(
  if_effective = median(wtp_1),
  if_ineffective = median(wtp_2)
)
