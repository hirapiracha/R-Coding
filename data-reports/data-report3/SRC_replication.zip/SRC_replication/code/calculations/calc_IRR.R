# Purpose: Derive Inter-Rater Reliability

######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))


##################################
#### DERIVE IRR FOR BELIEFS ######
##################################
# Load data
coded = readRDS(path_to("codes_preconflict"))
w = readRDS(path_to("wide"))
coded = coded %>% filter(ResponseId %in% w$ResponseId)

# IRR for simplified coding scheme
no_conflict = unique(coded$ResponseId) %>% sapply(., function(i) {
  (coded[coded$ResponseId %in% i, "code_effect_simple"] %>% unique %>% length == 1) * 1
})
mean(no_conflict)

# IRR for detailed coding scheme
no_conflict = unique(coded$ResponseId) %>% sapply(., function(i) {
  (coded[coded$ResponseId %in% i, "code_effect"] %>% unique %>% length == 1) * 1
})
mean(no_conflict)


#######################################
#### DERIVE IRR FOR CONSEQUENCES ######
#######################################
# Load data
coded = readRDS(path_to("codes_conseq_preconflict"))
w = readRDS(path_to("wide"))
coded = coded %>% filter(ResponseId %in% w$ResponseId)

# IRR for simplified coding scheme
no_conflict = unique(coded$ResponseId) %>% sapply(., function(i) {
  (coded[coded$ResponseId %in% i, "code_conseq_simple"] %>% unique %>% length == 1) * 1
})
mean(no_conflict)

# IRR for detailed coding scheme
no_conflict = unique(coded$ResponseId) %>% sapply(., function(i) {
  (coded[coded$ResponseId %in% i, "code_conseq"] %>% unique %>% length == 1) * 1
})
mean(no_conflict)

