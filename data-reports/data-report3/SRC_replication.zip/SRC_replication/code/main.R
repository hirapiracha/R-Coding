##################################################
################ PREPARATION #####################
##################################################
# Windows user: Use Sys.setlocale("LC_ALL", "English") in line 7.
# Clear environment and set encoding
rm(list=ls())
Sys.setlocale("LC_ALL", "en_US.UTF-8")

# Load packages required for this script
library(groundhog)
library(rjson)
source("code/misc/function_file_paths.R")
source("code/misc/function_reg.R")
groundhog_day = fromJSON(file=path_to("groundhog_day"))
packages = c(
  "haven", "stringi", "plyr", "dplyr", "tidyr",
  "labelled", "ggplot2", "ggpubr", "ggtext", "ggalluvial",
  "stargazer", "lmtest", "sandwich", "multiwayvcov", "tools", "car",
  "showtext", "patchwork", "tibble",
  "readr", "stringr", "anesrake", "scales", "ids"
)
groundhog.library(packages, groundhog_day)

# Install folders
source(path_to("install_folders"))

# Add fonts, start showtext
font_add_google("Roboto Condensed", "rob_con")
showtext_auto()


##################################################
################ CLEANING ########################
##################################################
# Cleaning
source(path_to("clean_survey"))
source(path_to("clean_robustness_beliefs"))
source(path_to("clean_text_beliefs"))
source(path_to("clean_text_conseq"))
source(path_to("merge"))
source(path_to("export_dta"))


##################################################
################ ANALYSIS ########################
##################################################
# Sample
source(path_to("tab_demographics"))
source(path_to("reg_attrition"))

# Beliefs
source(path_to("fig_beliefs"))
source(path_to("fig_beliefs_robust"))
source(path_to("reg_beliefs_hetero"))
source(path_to("fig_explanations"))
source(path_to("fig_explanations_robust"))

# Valuations
source(path_to("fig_conseq"))
source(path_to("fig_conseq_robust"))
source(path_to("fig_explanations_conseq"))
source(path_to("fig_explanations_conseq_robust"))
source(path_to("reg_conseq_hetero"))

# Beliefs: Robustness survey
source(path_to("tab_demographics_robustness"))
source(path_to("fig_robustness_studies"))

