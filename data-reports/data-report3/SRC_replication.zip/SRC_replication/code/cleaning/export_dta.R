# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Import
wide = readRDS(path_to("wide"))
robustness_beliefs = readRDS(path_to("robustness_beliefs"))
attrition = readRDS(path_to("attrition"))

# Adjust columns that cannot be exported to Stata
wide$quant_dec_less = as.numeric(wide$quant_dec_less)
wide$quant_dec_more = as.numeric(wide$quant_dec_more)
wide$quant_inc = as.numeric(wide$quant_inc)
wide$meat = as.numeric(wide$meat)
wide$flights = as.numeric(wide$flights)
wide$coffee = as.numeric(wide$coffee)
robustness_beliefs$more_prod = NULL
robustness_beliefs$less_prod = NULL
robustness_beliefs$increase_prod = NULL
robustness_beliefs$meat = NULL
robustness_beliefs$flights = NULL
robustness_beliefs$coffee = NULL
attrition$quant_dec_less = as.numeric(attrition$quant_dec_less)
attrition$quant_dec_more = as.numeric(attrition$quant_dec_more)
attrition$quant_inc = as.numeric(attrition$quant_inc)
attrition$meat = as.numeric(attrition$meat)
attrition$flights = as.numeric(attrition$flights)
attrition$coffee = as.numeric(attrition$coffee)

# Export
write_dta(wide, path_to("data_out", "wide.dta"))
write_dta(robustness_beliefs, path_to("data_out", "robustness_beliefs.dta"))
write_dta(attrition, path_to("data_out", "attrition.dta"))
