#### PREPARATION ####
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load aux function
source(path_to("function_reg"))

# Import data
w = readRDS(path_to("wide"))

# Define care variable, scale income and age
w$care = 1*!w$conseq_dontcare
w$income = w$income / 1000
w$age = w$age / 10

# Rename variable so that vig FE can be omitted
w$consumer = w$consumer_vig

# Define joint labels
joint_labels = " & \\mbox{\\textbf{Cares at all?}} & \\multicolumn{2}{c}{\\textbf{Valuation data}} & \\multicolumn{2}{c}{\\textbf{Explanation data}} \\\\\n"



#### DEFINE MODELS ####
models = list()
models$reg_conseq_hetero = list(
  label = "will_be_deleted_anyway",
  forms = list(
    "care" = formula(care ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(conseq)),
    "wtp_strict" = formula(conseq_strict ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(conseq)),
    "wtp_weak" = formula(conseq_weak ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(conseq)),
    "explain_strict" = formula(explanation_conseq_strict ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(conseq)),
    "explain_weak" = formula(explanation_conseq_weak ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(conseq))
  ),
  subsets = list(
    "care" = rep(T, nrow(w)),
    "wtp_strict" = w$wtp_1 > 0,
    "wtp_weak" = w$wtp_1 > 0,
    "explain_strict" = !is.na(w$code_conseq_simple),
    "explain_weak" = !is.na(w$code_conseq_simple)
  ),
  wgts = NULL,
  data_name = "w",
  teq_se = "rse",
  dep.var.caption = "",
  dep.var.labels = rep("", 6),
  column.labels = c("Positive valuation", "Strict conseq.", "Weak conseq.", "Strict conseq.", "Weak conseq."), 
  covariate.labels = c(
    "\\mbox{\\textbf{Female}}", "\\mbox{\\textbf{Age} (in 10y)}", "\\mbox{\\textbf{Income: 50-100k}}", "\\mbox{\\textbf{Income: 100k+}}",
    "\\mbox{\\textbf{Bachelor's degree}}", "\\mbox{\\textbf{Politics: Independent}}", "\\mbox{\\textbf{Politics: Republican}}",
    "\\mbox{\\textbf{Consumes good}}"
  ),
  notes = NULL,
  landscape = F,
  omit.var = c("region", "conseq"),
  font.size= "scriptsize",
  add.lines = list(
    c("Region FE", "$\\checkmark$","$\\checkmark$", "$\\checkmark$", "$\\checkmark$", "$\\checkmark$"),
    c("Case FE", "$\\checkmark$","$\\checkmark$", "$\\checkmark$", "$\\checkmark$", "$\\checkmark$")
  ),
  float=F,
  tabularx = T,
  omit.table.layout = "n"
)


#### RUN REGRESSIONS AND PRINT LATEX OUTPUT ####
models = reg_latex(models, file_name = "ignore.tex")

# Custom table adjustments
tab = readLines(path_to("tables", "reg_conseq_hetero.tex"))
tab[10] = joint_labels
writeLines(tab, path_to("tables", "reg_conseq_hetero.tex"))

# Show table
#compile_table("reg_conseq_hetero.tex", open=F)
# In case compilation doesn't work: setwd("../../..")


