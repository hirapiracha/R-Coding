#### PREPARATION ####
# Clear environment
rm(list=setdiff(ls(), "path_to"))
source(path_to("function_reg"))

# Import data
w = readRDS(path_to("robustness_beliefs"))
benchmark = read.csv2(path_to("demographics_benchmark"), as.is=T)
colnames(benchmark)[1] = "variable"
benchmark = benchmark %>% filter(tab_demo == 1)


#### DERIVE DEMOGRAPHICS ####
# Derive sample means
df = benchmark
df$production = sapply(df$variable, function(x) mean(w[w$condition == "production", x, drop=T]))
df$numeric = sapply(df$variable, function(x) mean(w[w$condition == "numeric", x, drop=T]))
df$beliefs_incentives = sapply(df$variable, function(x) mean(w[w$condition == "beliefs_incentives", x, drop=T]))

# Focus on relevant columns
df = df[, c("label", "freq", "production", "numeric", "beliefs_incentives")]
colnames(df) = c("Variable", "ACS (2022)", "Production", "Numeric Response", "Incentivized Beliefs")

# Round
df[, 2] = paste0(round(df[, 2] * 100, 0), "%") %>% as.character
df[, 3] = paste0(round(df[, 3] * 100, 0), "%") %>% as.character
df[, 4] = paste0(round(df[, 4] * 100, 0), "%") %>% as.character
df[, 5] = paste0(round(df[, 5] * 100, 0), "%") %>% as.character


# Sample size
df = rbind(df, c(
  "Sample size", "1,980,550", sum(w$condition == "production"),
  sum(w$condition == "numeric"), sum(w$condition == "beliefs_incentives")
))


#### TEX FILE: MAIN SAMPLE ####
# Stargazer
stargazer(
  df[,1:5], summary=F, out = path_to("tables", "tab_demographic_robustness.tex"), float=F,
  digits=2, rownames=F, font.size="footnotesize"
)

# First line left aligned
tab = paste(readLines(path_to("tables", "tab_demographic_robustness.tex")), collapse="\n")
splitter = " ccccc}"
tab = strsplit(tab, split=splitter, fixed=T)[[1]]

tab = paste0(
  tab[[1]],
  " p{37mm}>{\\centering\\arraybackslash}m{16mm}>{\\centering\\arraybackslash}m{16mm}>{\\centering\\arraybackslash}m{16mm}>{\\centering\\arraybackslash}m{16mm}}",
  tab[[2]],
  sep="\n"
)

# Add additional vertical sep
for (col in colnames(df)) {tab = sub(col, paste0("\\\\textbf{", col, "}"), tab)}
tab = sub("Female", " {\\\\scriptsize\\\\textbf{Gender}} \\\\\\\\ Female", tab)
tab = sub("18-34", "\\\\rule{-2pt}{2ex}     {\\\\scriptsize\\\\textbf{Age}} \\\\\\\\ 18-34", tab)
tab = sub("Below 50k", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Household net income}} \\\\\\\\ Below 50k", tab)
tab = sub("Bachelor's degree or more", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Education}} \\\\\\\\ Bachelor's degree or more", tab)
tab = sub("Northeast", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Region}} \\\\\\\\ Northeast", tab)
tab = sub("White", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Race and ethnicity}} \\\\\\\\ White", tab)
tab = sub("Democrat", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Political affiliation*}} \\\\\\\\ Democrat", tab)
tab = sub("Sample size & ", "\\\\\\midrule Sample size & ", tab)
tab = sub("African", "Afric.", tab)

# Headers bold
splitter = "\\hline \\\\[-1.8ex] "
tab = strsplit(tab, split=splitter, fixed=T)[[1]]

tab = paste0(
  tab[[1]],
  splitter,
  paste0(paste0("\\textbf{",colnames(df)[1:5],"}"), collapse=" & "),
  "\\\\",
  splitter,
  tab[[3]],
  splitter,
  tab[[4]],
  sep="\n"
)

# Save table
write(tab, file = path_to("tables", "tab_demographic_robustness.tex"))
#compile_table("tab_demographic_robustness.tex", open=F)
# In case compilation doesn't work: setwd("../../..")


