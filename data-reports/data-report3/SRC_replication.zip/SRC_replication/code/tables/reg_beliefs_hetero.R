#### PREPARATION ####
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load aux function
source(path_to("function_reg"))

# Import data
w = readRDS(path_to("wide"))

# Rescale income and age
w$income = w$income / 1000
w$age = w$age / 10

# Rename variable so that vig FE can be omitted
w$consumer = w$consumer_vig


#### DEFINE MODELS ####
models = list()
models$reg_beliefs_hetero = list(
  label = "will_be_deleted_anyway",
  forms = list(
    "belief" = formula(belief_dampening ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(vig)),
    "explanation" = formula(explanation_dampening ~ gender_female + age + income_50_100 + income_100plus + education_college + politics_independent + politics_republican + consumer + factor(region) + factor(vig))
  ),
  wgts = NULL,
  data_name = "w",
  teq_se = "rse",
  dep.var.caption = "",
  dep.var.labels = c("\\textbf{Belief in dampened effect} (partial or full dampening; binary)", "\\mbox{\\textbf{Explanation of dampened effect}} (binary)"), 
  covariate.labels = c(
    "\\textbf{Female} (binary)", "\\textbf{Age} (continuous, in 10y)", "\\mbox{\\textbf{Income: 50-100k} (binary)}", "\\mbox{\\textbf{Income: 100k+} (binary)}",
    "\\mbox{\\textbf{At least Bachelor's degree} (binary)}", "\\mbox{\\textbf{Politics: Independent} (binary)}", "\\mbox{\\textbf{Politics: Republican} (binary)}",
    "\\mbox{\\textbf{Consumes good} (binary)}"
  ),
  notes = NULL,
  landscape = F,
  omit.var = c("region", "vig"),
  font.size= "footnotesize",
  add.lines = list(
    c("Region FE", "$\\checkmark$", "$\\checkmark$"),
    c("Case FE", "$\\checkmark$", "$\\checkmark$")
  ),
  float=F,
  tabularx = T,
  omit.table.layout = "n"
)


#### RUN REGRESSIONS AND PRINT LATEX OUTPUT ####
models = reg_latex(models, file_name = "ignore.tex")

# Show table
#compile_table("reg_beliefs_hetero.tex", open=F)
# In case compilation doesn't work: setwd("../../..")


