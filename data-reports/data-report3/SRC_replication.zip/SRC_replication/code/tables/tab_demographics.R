#### PREPARATION ####
# Clear environment
rm(list=setdiff(ls(), "path_to"))
source(path_to("function_reg"))

# Import data
w = readRDS(path_to("wide"))
benchmark = read.csv2(path_to("demographics_benchmark"), as.is=T)
colnames(benchmark)[1] = "variable"
benchmark = benchmark %>% filter(tab_demo == 1)


#### DERIVE DEMOGRAPHICS ####
# Derive sample means
df = benchmark
df$sample = sapply(df$variable, function(x) mean(w[, x, drop=T]))

# Focus on relevant columns
df = df[, c("label", "freq", "sample")]
colnames(df) = c("Variable", "ACS (2022)", "Sample")

# Round
df[, 2] = paste0(round(df[, 2] * 100, 0), "%") %>% as.character
df[, 3] = paste0(round(df[, 3] * 100, 0), "%") %>% as.character


# Sample size
df = rbind(df, c(
  "Sample size", "1,980,550", format(dim(w)[1], big.mark=",")
))


#### TEX FILE: MAIN SAMPLE ####
# Stargazer
stargazer(
  df[,1:3], summary=F, out = path_to("tables", "tab_demo.tex"), float=F,
  digits=2, rownames=F, font.size="footnotesize"
)

# First line left aligned
tab = paste(readLines(path_to("tables", "tab_demo.tex")), collapse="\n")
splitter = " ccc}"
tab = strsplit(tab, split=splitter, fixed=T)[[1]]

tab = paste0(
  tab[[1]],
  " p{45mm}>{\\centering\\arraybackslash}m{20mm}>{\\centering\\arraybackslash}m{20mm}}",
  tab[[2]],
  sep="\n"
)

# Add additional vertical sep
for (col in colnames(df)) {tab = sub(col, paste0("\\\\textbf{", col, "}"), tab)}
tab = sub("Female", " {\\\\scriptsize\\\\textbf{Gender}} \\\\\\\\ Female", tab)
tab = sub("18-34", "\\\\rule{-2pt}{2ex}     {\\\\scriptsize\\\\textbf{Age}} \\\\\\\\ 18-34", tab)
tab = sub("Below 50k", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Household net income}} \\\\\\\\ Below 50k", tab)
tab = sub("Bachelor's degree or more", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Education}} \\\\\\\\ Bachelor's degree or more", tab)
tab = sub("Northeast", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Region}} \\\\\\\\ Northeast", tab)
tab = sub("White", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Race and ethnicity}} \\\\\\\\ White", tab)
tab = sub("Democrat", "\\\\rule{-2pt}{2ex}  {\\\\scriptsize\\\\textbf{Political affiliation*}} \\\\\\\\ Democrat", tab)
tab = sub("Sample size & ", "\\\\\\midrule Sample size & ", tab)

# Headers bold
splitter = "\\hline \\\\[-1.8ex] "
tab = strsplit(tab, split=splitter, fixed=T)[[1]]

tab = paste0(
  tab[[1]],
  splitter,
  paste0(paste0("\\textbf{",colnames(df)[1:3],"}"), collapse=" & "),
  "\\\\",
  splitter,
  tab[[3]],
  splitter,
  tab[[4]],
  sep="\n"
)

# Save table
write(tab, file = path_to("tables", "tab_demo.tex"))
#compile_table("tab_demo.tex", open=F)


