#### PREPARATION ####
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load aux function
source(path_to("function_reg"))

# Import data
w = readRDS(path_to("attrition"))

# Rescale income
w$income = w$income / 1000


#### DEFINE MODELS ####
models = list()
models$reg_attrition = list(
  label = "will_be_deleted_anyway",
  forms = list(
    "attrition" = formula(final_sample ~ gender_female + age + income_50_100 + income_100plus + education_college + region_midwest + region_south + region_west)
  ),
  wgts = NULL,
  data_name = "w",
  teq_se = "rse",
  dep.var.caption = "",
  dep.var.labels = "\\textbf{Respondent is part of final sample} (binary dummy)", 
  covariate.labels = c(
    "\\textbf{Female} (binary dummy)", "\\textbf{Age} (continuous)", "\\textbf{Income: 50-100k} (binary dummy)", "\\textbf{Income: 100k+} (binary dummy)",
    "\\mbox{\\textbf{At least Bachelor's degree} (binary dummy)}", "\\textbf{Region: Midwest} (binary dummy)", "\\textbf{Region: South} (binary dummy)", "\\textbf{Region: West} (binary dummy)"
  ),
  notes = NULL,
  landscape = F,
  font.size= "footnotesize",
  float=F,
  tabularx = T,
  omit.table.layout = "n"
)


#### RUN REGRESSIONS AND PRINT LATEX OUTPUT ####
models = reg_latex(models, file_name = "ignore.tex")

# Show table
#compile_table("reg_attrition.tex", open=F)
# In case compilation doesn't work: setwd("../../..")


