######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
s = readRDS(path_to("wide"))
s = s %>% filter(!is.na(code_effect_simple))


######################
#### DERIVE DATA #####
######################
# Anticipated effects
df = rbind(
  s %>% group_by(vig, code_effect_simple) %>%
    summarise(n = n()) %>%
    mutate(
      freq = n / sum(n, na.rm=T),
  ) %>% filter(code_effect_simple != "dampening"),
  s %>% group_by(vig, code_effect_simple = code_effect) %>%
    summarise(n = n()) %>%
    mutate(
      freq = n / sum(n, na.rm=T),
    ) %>% filter(code_effect_simple %in% c("dampening", "tiny")),
  s %>% group_by(code_effect_simple) %>%
    summarise(n = n()) %>%
    mutate(
      vig = "pooled",
      freq = n / sum(n, na.rm=T),
  )  %>% filter(code_effect_simple != "dampening"),
  s %>% group_by(code_effect_simple = code_effect) %>%
    summarise(n = n()) %>%
    mutate(
      vig = "pooled",
      freq = n / sum(n, na.rm=T),
    ) %>% filter(code_effect_simple %in% c("dampening", "tiny"))
)
df$code_effect_simple = factor(df$code_effect_simple, levels=c("other", "spillover", "naive", "tiny", "dampening"))

# Labels
df$label = ifelse(
  df$freq >= 0.005,
  paste0(round(df$freq*100), "%"),
  paste0(round(df$freq*100, 1), "%")
)
df$number = plyr::mapvalues(df$code_effect_simple, from=c("other", "spillover", "naive", "dampening"), to=c(1:4)) %>%
  as.numeric
df$ypos = sapply(1:nrow(df), function(x) {
  1 - sum(df$freq[df$number < df$number[x] & df$vig == df$vig[x]]) -
    df$freq[x]/2
})
df$ypos[df$code_effect_simple == "dampening"] = 0.03
df$ypos[df$code_effect_simple == "tiny" & df$vig == "subelectricity"] = 0.08

# Don't display other fraction
df = df %>% filter(code_effect_simple != "other")

# Order
vigs = c(
  "pooled" = "**All cases**",
  "fuel" = "Fuel",
  "meat" = "Meat",
  "energy" = "Energy",
  "flights" = "Plane trips",
  "subelectricity" = "Green<br>electricity",
  "subhouse" = "Energy-efficient<br>home",
  "subclothing" = "2nd-hand<br>clothing",
  "subcoffee" = "Fairtrade<br>coffee"
)

######################
#### PLOT ############
######################
plots = list()

plots$fig_explanations = ggplot(df, aes(x = vig, y = freq, fill = code_effect_simple, label = label)) +
  geom_bar(stat = "identity") +
  geom_text(aes(y = ypos), family="rob_con", size = 4) +
  geom_vline(xintercept = 1.5) +
  geom_vline(xintercept = 5.5) +
  xlab("Consumption reduction case") + ylab("Frequency") +
  coord_cartesian(ylim=c(-0.04, 1)) +
  scale_x_discrete(limits = names(vigs), labels=vigs) +
  scale_y_continuous(breaks=seq(0, 1, 0.2), labels=paste0(100*seq(0, 1, 0.2), "%")) +
  scale_fill_manual(
    values=c("darkolivegreen2", "skyblue", "red1", "red3"),
    labels=c("Positive multiplier  ", "One-to-one impact  ", "Dampened impact:   \nToo small to matter", "Dampened impact:   \nOffset by others   "),
    name = "**Explanation**: Respondents explain a ..."
  ) +
  theme_minimal() +
  theme(
    text = element_text(family = "rob_con"),
    plot.title = element_text(size=18, face="bold", hjust=0.5),
    legend.position = "bottom",
    legend.direction = "vertical",
    legend.title = element_markdown(size=14, hjust=0.5),
    #legend.spacing.y = unit(0, 'cm'),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    axis.title = element_text(face="bold", size=14),
    axis.text.x = element_markdown(size=14),
    axis.text.y = element_text(size=14),
    legend.text = element_text(size=14)
  ) +
  guides(fill = guide_legend(nrow = 1, reverse = TRUE)) +
  geom_text(aes(x = x, y = y, label = label), data = data.frame(
    x = c(1, 3.5, 7.5),
    y = c(-0.05, -0.05, -0.05),
    label = c("Pooled", "Reducing consumption of", "Switching to"),
    code_effect_simple = "naive"
  ), family = "rob_con", fontface = "bold", size = 5
  )

# Save generated graph.
pdf(path_to("figures", "fig_explanations.pdf"), width=11, height=5.5)
print(plots$fig_explanations)
dev.off()  

