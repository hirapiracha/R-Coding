######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
s = readRDS(path_to("wide"))


######################
#### DERIVE DATA #####
######################

# Distribution
dist = rbind(
  s %>% group_by(conseq) %>% summarise(
    "not defined" = mean(wtp_ratio_class %in% NA),
    "0" = mean(wtp_ratio_class %in% "0", na.rm=T),
    "(0,0.25]" = mean(wtp_ratio_class %in% "(0,0.25]", na.rm=T),
    "(0.25,0.5]" = mean(wtp_ratio_class %in% "(0.25,0.5]", na.rm=T),
    "(0.5,0.75]" = mean(wtp_ratio_class %in% "(0.5,0.75]", na.rm=T),
    "(0.75,1)" = mean(wtp_ratio_class %in% "(0.75,1)", na.rm=T),
    "1" = mean(wtp_ratio_class %in% "1", na.rm=T)
  ),
  s %>% summarise(
    conseq = "pooled",
    "not defined" = mean(wtp_ratio_class %in% NA),
    "0" = mean(wtp_ratio_class %in% "0", na.rm=T),
    "(0,0.25]" = mean(wtp_ratio_class %in% "(0,0.25]", na.rm=T),
    "(0.25,0.5]" = mean(wtp_ratio_class %in% "(0.25,0.5]", na.rm=T),
    "(0.5,0.75]" = mean(wtp_ratio_class %in% "(0.5,0.75]", na.rm=T),
    "(0.75,1)" = mean(wtp_ratio_class %in% "(0.75,1)", na.rm=T),
    "1" = mean(wtp_ratio_class %in% "1", na.rm=T)
  )
) %>% pivot_longer(c(2:8))
dist$name = factor(dist$name, levels=c("not defined", levels(s$wtp_ratio_class)))
dist$label = ifelse(
  dist$value >= 0.0051,
  paste0(round(dist$value*100), "%"),
  paste0(round(dist$value*100, 1), "%")
)


######################
#### PLOT ############
######################
plots = subplots = list()

plots$fig_conseq = ggplot(dist, aes(x = conseq, y = value, fill = name, label = label)) +
  geom_bar(stat = "identity", position = position_dodge(.85), width=0.8) +
  geom_text(aes(y = value + 0.03), position = position_dodge(0.85), family="rob_con", size = 4) +
  geom_vline(xintercept = 1.5) +
  xlab("Externality") + ylab("Frequency") +
  scale_x_discrete(
    limits = c("pooled", "co2", "waste", "chicken", "textile"),
    labels = c("**All cases**", "CO2 emissions<br>(Reduce by 1 ton)", "Non-recyclable waste<br>(Reduce by 100 pounds)", "Animal welfare<br>(20 certified chicken)", "Low wages<br>(10 fairtrade garments)")
  ) +
  scale_y_continuous(breaks=seq(0, 1, 0.2), labels=paste0(100*seq(0, 1, 0.2), "%")) +
  coord_cartesian(ylim =c(0, 0.8)) +
  scale_fill_manual(
    values=c("gray90", "red3", "#e06258", "#d68f8e", "#cfb5ba", "#b9c2d0", "lightblue2"),
    labels=paste0(c("(Not valued)", levels(s$wtp_ratio_class)), " "),
    name="**Valuation ratio**: valuation if ineffective / valuation if effective *(from left to right)*"
  ) +
  theme_minimal() +
  theme(
    text = element_text(family = "rob_con"),
    #axis.line.y = element_line(),
    plot.title = element_blank(),#element_text(size=18, face="bold", hjust=0.5),
    legend.position = "bottom",#c(0.5, 0.83),
    legend.direction = "vertical",
    legend.title = element_markdown(size=14, hjust=0.5),
    legend.spacing.y = unit(0, 'cm'),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    axis.title = element_text(face="bold", size=14),
    axis.text.x = element_markdown(size=14),
    axis.text.y = element_text(size=14),
    legend.text = element_text(size=14)
  ) + 
  guides(fill = guide_legend(nrow = 1))


# Save generated graph.
pdf(path_to("figures", "fig_conseq.pdf"), width=11, height=4)
print(plots$fig_conseq)
dev.off()  


