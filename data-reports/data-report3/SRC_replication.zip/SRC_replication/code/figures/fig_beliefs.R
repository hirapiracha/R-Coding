######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
s = readRDS(path_to("wide"))


######################
#### DERIVE DATA #####
######################
# Anticipated effects
df = rbind(
  s %>% group_by(vig, effect) %>%
    summarise(n = n()) %>%
    mutate(
      freq = n / sum(n, na.rm=T), effect=factor(effect),
  ),
  s %>% group_by(effect) %>%
    summarise(n = n()) %>%
    mutate(
      vig = "pooled",
      freq = n / sum(n, na.rm=T), effect=factor(effect),
  )
)

# Labels
df$label = ifelse(
  df$freq >= 0.005,
  paste0(round(df$freq*100), "%"),
  paste0(round(df$freq*100, 1), "%")
)
df$ypos = sapply(1:nrow(df), function(x) {
  1 - sum(df$freq[as.numeric(df$effect) < as.numeric(df$effect[x]) & df$vig == df$vig[x]]) -
    df$freq[x]/2
})
df$ypos[df$effect == 1] = 0.98
df$ypos[df$effect == 2] = 0.8
df$ypos[df$effect == 4] = 0.1
df$ypos[df$effect == 5] = 0.02


# Order
vigs = c(
  "pooled" = "**All cases**",
  "fuel" = "Fuel",
  "meat" = "Meat",
  "energy" = "Energy",
  "flights" = "Plane trips",
  "subelectricity" = "Green<br>electr.",
  "subhouse" = "Energy-eff.<br>home",
  "subclothing" = "2nd-hand<br>clothing",
  "subcoffee" = "Fairtrade<br>coffee"
)

######################
#### PLOT ############
######################
plots = list()

plots$fig_beliefs = ggplot(df, aes(x = vig, y = freq, fill = effect, label = label)) +
  geom_bar(stat = "identity") +
  geom_text(aes(y = ypos), family="rob_con", size = 4) +
  geom_vline(xintercept = 1.5) +
  geom_vline(xintercept = 5.5) +
  xlab("Consumption reduction case") + ylab("Frequency") +
  #ggtitle("Beliefs in dampening") +
  coord_cartesian(ylim=c(-0.04, 1)) +
  scale_x_discrete(limits = names(vigs), labels=vigs) +
  scale_y_continuous(breaks=seq(0, 1, 0.2), labels=paste0(100*seq(0, 1, 0.2), "%")) +
  scale_fill_manual(
    values=c("darkolivegreen2", "skyblue", "orange2", "red2", "red4"),
    labels=c("decreases by more", "decreases one-to-one", "decreases by less", "does not change", "actually increases"),
    name = "**Belief**: In response to decrease in own consumption, aggregate consumption (of the dirty good) ..."
  ) +
  theme_minimal() +
  theme(
    text = element_text(family = "rob_con"),
    plot.title = element_blank(),#element_text(size=18, face="bold", hjust=0.5),
    legend.position = "bottom",
    legend.direction = "vertical",
    legend.title = element_markdown(size=14, hjust=0.5),
    #legend.spacing.y = unit(0, 'cm'),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    axis.title = element_text(face="bold", size=14),
    axis.text.x = element_markdown(size=14),
    axis.text.y = element_text(size=14),
    legend.text = element_text(size=14)
  ) +
  guides(fill = guide_legend(nrow = 1)) +
  geom_text(aes(x = x, y = y, label = label), data = data.frame(
    x = c(1, 3.5, 7.5),
    y = c(-0.05, -0.05, -0.05),
    label = c("Pooled", "Reducing consumption of", "Switching to"),
    effect = NA
  ), family = "rob_con", fontface = "bold", size = 5
  )

# Save generated graph.
pdf(path_to("figures", "fig_beliefs.pdf"), width=11, height=5.5)
print(plots$fig_beliefs)
dev.off()  
