######################
##### PREPARATION ####
######################
# Clear environment
rm(list=setdiff(ls(), "path_to"))

# Load data
s = readRDS(path_to("wide"))
s = s %>% filter(!is.na(code_conseq_simple))


######################
#### DERIVE DATA #####
######################
# Anticipated effects
df = rbind(
  s %>% group_by(conseq) %>% summarise(
    freq_conseq = mean(grepl("conseq", code_conseq_simple) & !grepl("deont", code_conseq_simple)),
    freq_both   = mean(grepl("conseq", code_conseq_simple) & grepl("deont", code_conseq_simple)),
    freq_deont  =  mean(!grepl("conseq", code_conseq_simple) & grepl("deont", code_conseq_simple)),
    freq_other  =  mean(grepl("other", code_conseq_simple))
  ),
  s %>% summarise(
    freq_conseq = mean(grepl("conseq", code_conseq_simple) & !grepl("deont", code_conseq_simple)),
    freq_both   = mean(grepl("conseq", code_conseq_simple) & grepl("deont", code_conseq_simple)),
    freq_deont =  mean(!grepl("conseq", code_conseq_simple) & grepl("deont", code_conseq_simple)),
    freq_other  =  mean(grepl("other", code_conseq_simple))
  ) %>% mutate(conseq = "pooled")
) %>% pivot_longer(2:5, values_to = "freq", names_to = "code")
df$code = gsub("freq_", "", df$code)
df$code = factor(df$code, levels=c("other", "deont", "both", "conseq"))

# Labels
df$label = ifelse(
  df$freq >= 0.005,
  paste0(round(df$freq*100), "%"),
  paste0(round(df$freq*100, 1), "%")
)
df$number = plyr::mapvalues(df$code, from=c("other", "deont", "both", "conseq"), to=c(1:4)) %>%
  as.numeric
df$ypos = sapply(1:nrow(df), function(x) {
  1 - sum(df$freq[df$number < df$number[x] & df$conseq == df$conseq[x]]) -
    df$freq[x]/2
})
df$ypos[df$code == "conseq"] = 0.05
df$ypos[df$code == "deont" & df$conseq == "textile"] = 0.95

# Don't display other fraction
df = df %>% filter(code != "other")

# Order
conseqs = c(
  "pooled" = "**All cases**",
  "co2" = "CO2 emissions<br>(Reduce by 1 ton)",
  "waste" = "Non-recyclable waste<br>(Reduce by<br>100 pounds)",
  "chicken" = "Animal welfare<br>(20 certified<br>chicken)",
  "textile" = "Low wages<br>(10 fairtrade<br>garments)"
)

######################
#### PLOT ############
######################
plots = list()
plots$fig_explanations_conseq = ggplot(df, aes(x = conseq, y = freq, fill = code, label = label)) +
  geom_bar(stat = "identity") +
  geom_text(aes(y = ypos), family="rob_con", size = 4) +
  geom_vline(xintercept = 1.5) +
  xlab("Externality") + ylab("Frequency") +
  coord_cartesian(ylim=c(0, 1)) +
  scale_x_discrete(limits = names(conseqs), labels=conseqs) +
  scale_y_continuous(breaks=seq(0, 1, 0.2), labels=paste0(100*seq(0, 1, 0.2), "%")) +
  scale_fill_manual(
    values=c("skyblue", "#B0858D", "red2"),
    labels=c("Action / direct effect  ", "Both  ", "Consequences / total effect"),
    name = "**Explanation**: Respondent cares about ..."
  ) +
  theme_minimal() +
  theme(
    text = element_text(family = "rob_con"),
    plot.title = element_text(size=18, face="bold", hjust=0.5),
    legend.position = "bottom",
    legend.direction = "vertical",
    legend.title = element_markdown(size=14, hjust=0.5),
    #legend.spacing.y = unit(0, 'cm'),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    axis.title = element_text(face="bold", size=14),
    axis.text.x = element_markdown(size=12),
    axis.text.y = element_text(size=14),
    legend.text = element_text(size=14)
  ) +
  guides(fill = guide_legend(nrow = 1, reverse = TRUE))

# Save generated graph.
pdf(path_to("figures", "fig_explanations_conseq.pdf"), width=8, height=5.5)
print(plots$fig_explanations_conseq)
dev.off()

